package mastermindgui;

/*
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;

class AppControllerTest {

    @Test
    void testCorrectColors(){/*

        TODO: hente ut farge til spesifikke bokser
        sette koden lik en spesifikk string
        sammenligne

        Guessget guess = new Guessget();
        guess.code = "AABC";
        updateCharGrid();
    }

}
*/
